from django.contrib import admin
from .models import Propiedad, PropiedadImagen

admin.site.register(Propiedad)
admin.site.register(PropiedadImagen)
